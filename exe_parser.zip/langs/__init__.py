__all__ = ['en', 'ru']

from langs import *

langs = {
    'English': en,
    'Russian': ru
}